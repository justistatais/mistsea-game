# CP-RF-05 — 第七座灯塔：内部完整章回归、连续过渡与体验采样

阶段：CONTENT｜类型：chapter_qa｜责任：Codex工程实现
初始状态：未开始。

## 目标
从上一章真实状态进入第七座灯塔并形成下一章合法出口；测试所有重要方法、选择与保存边界。

## 前置条件
CP-RF-02, CP-RF-03, CP-RF-04, CX-064, CX-070, CX-071, CX-073, CX-074
所有前置必须实际验收；Gate通过由其依赖证据派生，不手写passed。

## 先读
- AGENTS.md
- docs/integration/MASTER_GDD_v0.1.md
- docs/integration/Integration_Decisions_v0.1.md
- docs/baseline/World_Story_Bible_v0.1.md
- docs/baseline/Exploration_Level_Design_v0.1.md
- docs/baseline/Quest_Event_System_v0.1.md
- docs/baseline/English_Learning_System_v0.1.md
- docs/baseline/Puzzle_System_v0.1.md
- docs/baseline/Character_Progression_v0.1.md
- docs/baseline/Combat_System_v0.1.md
- docs/baseline/NPC_Faction_System_v0.1.md
- docs/baseline/UI_UX_Spec_v0.1.md
- docs/baseline/Content_AI_Pipeline_v0.1.md

涉及任务：Q-F01, Q-F02, Q-F03, Q-F04, Q-F05
涉及场景：RF-S01, RF-S02, RF-S03, RF-S04, RF-S05, RF-S06, RF-S07

## 允许修改范围
- `tests/Chapters/RF/`
- `reports/chapters/RF/`
- `content/source/RF/`

## 必须交付
- 完整与乱序路线
- 最低成长配置测试
- 语言机会/时间分布
- 内部缺陷与明确未测项

## 验收
- 不得只靠测试关卡seed证明连续主线
- 字幕/完整提示不改变基本奖励
- 撤回不重置外部进展
- 声画/材料/规则版本一致
- 内部通过不冒充校准

## 上位验收责任
STORY-AT-13, EXP-AT-31, COM-AT-41

## 禁止与遇阻处理
不得编辑 docs/baseline/ 或 reference/ 原件；不得删除用户代码、强制重置Git、安装未声明付费服务、上传正文或发布产品。跨出允许范围时先登记依赖/变更并停止相关修改。
不得把未实现分支返回true、把SYNTHETIC当真实、把脚本当音轨、把结构化选择当自由英文理解；不得擅改6.5目标、奖励、事实、结局和资源所有权。
本卡过大或发现缺失制作条件时，保留已完成可检验内容并登记blocked；先提出有范围的子卡，不直接扩大到全游戏。没有原生Windows/真人/模型权限时如实保留未执行项目。

## 交付证据
写入 `reports/execution/CP-RF-05.json`，采用 planning/templates/Task_Report.template.json。记录真实提交/工作树差异、命令、退出码、环境、测试名称、未执行项和来源版本；不能填写估计的通过数。

任务状态只有在产物、证据和所需复核均成立后才改为accepted。代码已编写不等于已验证；Gate、模型评价与真人签核不能自行伪造。
